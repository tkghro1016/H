/* *****************************************************************************
 *  Name:              Lee Ki Heun
 *  Coursera User ID:  tkghro1016@gmail.com
 *  Last modified:     May 23, 2021
 **************************************************************************** */

import edu.princeton.cs.algs4.Insertion;

public class FastCollinearPoints {
    private LineSegment[] lineList;

    // finds all line segments containing 4 or more points
    public FastCollinearPoints(Point[] points) {
        if (points == null) {
            throw new IllegalArgumentException();
        }
        lineList = new LineSegment[points.length];

        // input을 직접 가리키지 않게 복사
        Point[] pointList = new Point[points.length];
        for (int i = 0; i < points.length; i++) {
            if (points[i] == null) {
                throw new IllegalArgumentException();
            }
            pointList[i] = points[i];
        }

        int lineIndex = 0;

        for (int i = 0; i < pointList.length; i++) {
            Point[] orderPoints = new Point[pointList.length - i - 1];
            for (int j = i + 1; j < pointList.length; j++) {
                if (pointList[i].compareTo(pointList[j]) == 0) {
                    throw new IllegalArgumentException();
                }
                orderPoints[j - i - 1] = pointList[j];
            }
            sort(pointList[i], orderPoints);
            if (orderPoints.length < 3) {
                break;
            }
            else {
                for (int j = 0; j < orderPoints.length - 2; j++) {
                    int count = 0;
                    for (int k = j + 1; k < orderPoints.length; k++) {
                        if (pointList[i].slopeTo(orderPoints[j]) == pointList[i]
                                .slopeTo(orderPoints[k])) {
                            count += 1;
                        }
                        else if (count > 0) {
                            lineList[lineIndex++] = new LineSegment(pointList[i], orderPoints[k]);
                            if (lineIndex == lineList.length) {
                                lineList = resize(lineList);
                            }
                        }
                        else {
                            break;
                        }
                    }
                }
            }
        }
        properSize();
    }

    private LineSegment[] resize(LineSegment[] lineSegmentList) {
        int n = lineSegmentList.length;
        LineSegment[] copy = new LineSegment[2 * n];
        for (int i = 0; i < n; i++)
            copy[i] = lineSegmentList[i];
        return copy;
    }

    private void properSize() {
        int n = 0;
        for (int i = 0; i < lineList.length; i++) {
            if (lineList[i] == null) {
                break;
            }
            n += 1;
        }
        LineSegment[] copy = new LineSegment[n];
        for (int i = 0; i < n; i++)
            copy[i] = lineList[i];
        lineList = copy;
        copy = null;
    }

    // the number of line segments
    public int numberOfSegments() {
        return lineList.length;
    }

    // the line segments
    public LineSegment[] segments() {
        // 직접 변수를 조정할 수 없도록 복사
        LineSegment[] copy = new LineSegment[lineList.length];
        for (int i = 0; i < lineList.length; i++) {
            copy[i] = lineList[i];
        }
        return copy;
    }

    private void merge(Point source, Point[] orderList, Point[] aux, int lo, int mid, int hi) {
        // copy to aux[]
        for (int k = lo; k <= hi; k++) {
            aux[k] = orderList[k];
        }

        // merge back to a[]
        int i = lo, j = mid + 1;
        for (int k = lo; k <= hi; k++) {
            if (i > mid) aux[k] = orderList[j++];
            else if (j > hi) aux[k] = orderList[i++];
            else if (source.slopeOrder().compare(orderList[i], orderList[j]) < 0)
                aux[k] = orderList[j++];
            else aux[k] = orderList[i++];
        }
    }

    private void sort(Point source, Point[] orderList, Point[] aux, int lo, int hi) {
        if (hi <= lo + 6) {
            Insertion.sort(orderList, lo, hi);
            return;
        }
        int mid = lo + (hi - lo) / 2;
        sort(source, orderList, aux, lo, mid);
        sort(source, orderList, aux, mid + 1, hi);
        if (source.slopeTo(orderList[mid + 1]) >= source.slopeTo(orderList[mid])) return;
        merge(source, orderList, aux, lo, mid, hi);
    }

    private void sort(Point source, Point[] orderList) {
        Point[] aux = new Point[orderList.length];
        sort(source, orderList, aux, 0, orderList.length - 1);
    }
}
