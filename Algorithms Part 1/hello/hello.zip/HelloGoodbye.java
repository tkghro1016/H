/* *****************************************************************************
 *  Name:              Lee Ki Heun
 *  Coursera User ID:  tkghro1016@gmail.com
 *  Last modified:     May 16, 2021
 **************************************************************************** */

public class HelloGoodbye {

    public static void main(String[] args) {
        String str1 = args[0];
        String str2 = args[1];

        System.out.println("Hello " + str1 + " and " + str2 + ".");
        System.out.println("Goodbye " + str2 + " and " + str1 + ".");
    }

}
