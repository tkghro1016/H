/* *****************************************************************************
 *  Name:              Lee Ki Heun
 *  Coursera User ID:  tkghro1016@gmail.com
 *  Last modified:     May 16, 2021
 **************************************************************************** */

public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, World");
    }
}
